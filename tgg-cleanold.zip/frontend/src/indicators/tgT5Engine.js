/**
 * tgT5Engine.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Frontend copy of backend/src/strategies/tgT5.js (TgT5Engine — the pure Pine
 * port of "TG T5 — Script A v16.30 BETA").
 *
 * This file is a byte-for-byte copy of the engine class + its pivot/series
 * helpers from the backend strategy module — NO trading-logic lines were
 * changed. Only an ES-module export list was appended at the bottom so the
 * frontend (which uses import/export, not CommonJS) can consume it directly.
 * If the T5 detection rules ever change, update backend/src/strategies/tgT5.js
 * first and re-sync this copy (or replace it with a shared package) so the
 * scanner and the chart indicator never drift apart.
 *
 * Used by indicators/T5Indicator.js to draw the same points/tags/flips on the
 * chart, live, as the backend scanner finds when it runs the T5 strategy.
 * ─────────────────────────────────────────────────────────────────────────────
 */

'use strict';

/**
 * TG T5 — Node.js port of "TG T5 — Script A v16.30 BETA" (Pine v6 indicator)
 * ════════════════════════════════════════════════════════════════════════
 * Implements Annexure A · Edition A5 (R33·10-57 + freeze queue Sr. 58-126)
 * exactly as the Pine indicator computes it: the MH/ML morning frame, the
 * 9EMA band, trend hysteresis, pivot detection (fast + slow roads), and
 * the full T5H (double-top/short) and T5L (double-bottom/long) point
 * state machines (points 1-6, caution box (Sr. 111/124), gate-2 re-anchor
 * (Sr. 100/108/114/122), gate-3 room filter, trap-flip invalidation
 * (Sr. 92/96/124b), expiry).
 *
 * v16.30 port notes (Sr. 111-126, superseding the prior v16.15 port):
 *  - Sr. 113: no more session/day reset for the T5H/T5L structures —
 *    armed structures now survive the session boundary. Only MH/ML and
 *    symScale still reset daily.
 *  - Sr. 111/124: "dissolution" is retired. Caution is now a two-sided
 *    box (CautLow/CautHigh) resolved purely by CLOSE; a close beyond
 *    either side is a genuine actionable flip (S/L T5H3/T5L3 FLIP), never
 *    a quiet close-based hand-off.
 *  - Sr. 112/116/118/121: the retained origin (lastPLBelow/lastPHTouch)
 *    now ratchets (only moves toward the structure, never away) and gates
 *    the point-2-first arming road; hand-off seeds require both recency
 *    and cross-machine idleness, and fall back to the retained origin on
 *    failure instead of dropping silently.
 *  - Sr. 114/122/126: the point-4 acceptance window is now capped AND
 *    floored (t5h/t5lP4Cap / P4Near) relative to point 2, with a stricter
 *    >=2-bar spacing from point 3.
 *  - Sr. 117: same-bar dip-vs-ratchet arbitration (earlier bar wins).
 *  - Sr. 119: a "dummy" point-5 NC that advances the cycle to hunt point 6
 *    without firing a signal when the real band-poke test misses narrowly.
 *  - Sr. 124b: the trap flip gains a second, looser close-based trigger.
 *
 * This is a *signal engine*, not a drawing script — all chart-only Pine
 * code (labels, boxes, the state panel, the DEBUG origin-touch overlay)
 * is intentionally left out. Every `alertcondition(...)` in the source
 * has a 1:1 event emitted here, plus the cheat-sheet's WAIT/INFO tags
 * (NC, CAUT, done, expired, gate-2 re-arm, gate-3 suppression)
 * so downstream code has the same context a chart-watching trader would.
 *
 * Usage
 * ─────
 *   const { TgT5Engine } = require('./tgT5Strategy');
 *   const engine = new TgT5Engine({ timezone: 'Asia/Kolkata' });
 *   for (const candle of closedCandles) {
 *     const { events, state } = engine.addBar(candle);
 *     for (const ev of events) if (ev.actionable) console.log(ev);
 *   }
 *
 * `candle` = { time: <ms epoch, UTC>, open, high, low, close }. Feed only
 * CLOSED candles — every gate in the Pine source is wrapped in
 * `barstate.isconfirmed`, so `addBar()` is that gate; there is no partial/
 * intrabar state mutation here (see `checkIntrabar()` below for the four
 * genuinely-intrabar watchers from Sr. 54, which read but never mutate).
 *
 * NOTE on pivots: `ta.pivothigh/pivotlow` tie-break behaviour is not
 * publicly specified bit-for-bit by TradingView. The implementation below
 * uses the conventional "candidate >= left neighbours, > right neighbours"
 * (mirrored for lows) rule that matches TradingView output in the
 * overwhelming majority of cases. If you see a pivot disagree with the
 * chart on a bar with an exact tied high/low, that tie-break is the place
 * to look.
 * ════════════════════════════════════════════════════════════════════════
 */

// ── small utilities ───────────────────────────────────────────────────
const na = (v) => v === undefined || v === null || Number.isNaN(v);
const nz = (v, fallback) => (na(v) ? fallback : v);

class Series {
  constructor() { this._a = []; }
  push(v) { this._a.push(v); return this._a.length - 1; }
  /** offset 0 = current (just pushed) bar, 1 = previous bar, ... */
  get(offset = 0) {
    const i = this._a.length - 1 - offset;
    return i >= 0 ? this._a[i] : undefined;
  }
  /** value at an absolute bar index (0-based, as assigned by the engine) */
  at(absIndex) {
    return (absIndex >= 0 && absIndex < this._a.length) ? this._a[absIndex] : undefined;
  }
  get length() { return this._a.length; }
}

function pivotHigh(highSeries, leftbars, rightbars) {
  const n = highSeries.length;
  const candIdx = n - 1 - rightbars;
  if (candIdx - leftbars < 0) return undefined;
  const candidate = highSeries.at(candIdx);
  for (let i = 1; i <= leftbars; i++) if (highSeries.at(candIdx - i) > candidate) return undefined;
  for (let i = 1; i <= rightbars; i++) if (highSeries.at(candIdx + i) >= candidate) return undefined;
  return candidate;
}
function pivotLow(lowSeries, leftbars, rightbars) {
  const n = lowSeries.length;
  const candIdx = n - 1 - rightbars;
  if (candIdx - leftbars < 0) return undefined;
  const candidate = lowSeries.at(candIdx);
  for (let i = 1; i <= leftbars; i++) if (lowSeries.at(candIdx - i) < candidate) return undefined;
  for (let i = 1; i <= rightbars; i++) if (lowSeries.at(candIdx + i) <= candidate) return undefined;
  return candidate;
}

/** The 10 tags a trader/consumer should actually ACT on (cheat-sheet rule 1). */
const ACTIONABLE_TAGS = new Set([
  'S T5H4', 'S T5H6', 'S T5H5 FLIP', 'S T5H2 FLIP', 'S T5L FLIP (trap)', 'S T5H3 FLIP',
  'L T5L4', 'L T5L6', 'L T5L5 FLIP', 'L T5L2 FLIP', 'L T5H FLIP (trap)', 'L T5L3 FLIP',
]);

// ── the engine ───────────────────────────────────────────────────────
class TgT5Engine {
  constructor(opts = {}) {
    // Inputs (mirrors the Pine `input.*` block) ---------------------------
    this.autoScale = opts.autoScale ?? true;
    this.trendMode = opts.trendMode ?? 'Auto'; // Auto | Force UP | Force DOWN | Force SIDEWAYS
    this.t5PendingBars = opts.t5PendingBars ?? 6;
    this.t5FlipFib = opts.t5FlipFib ?? 0.236;
    this.t5RoomToP3In = opts.t5RoomToP3 ?? 30.0;
    this.bandNearIn = opts.bandNear ?? 2.0;
    this.timezone = opts.timezone ?? 'Asia/Kolkata'; // for the session/newDay boundary

    // ── bar history series ────────────────────────────────────────────
    this.O = new Series(); this.H = new Series(); this.L = new Series(); this.C = new Series();
    this.isGreenS = new Series(); this.bodyTopS = new Series(); this.bodyBotS = new Series();
    this.bandHighS = new Series(); this.bandLowS = new Series();
    // timeS mirrors O/H/L/C one-for-one (same push cadence, same absolute
    // bar index) so any point whose bar is discovered *after* the fact
    // (pivot points, which only confirm 1-2 bars later — see pivotHigh/
    // pivotLow) can still be stamped with the time of the candle it
    // actually happened on, not the candle that merely confirmed it.
    this.timeS = new Series();
    this.barIndex = -1;

    // EMA(9) state
    this._emaHighPrev = undefined;
    this._emaLowPrev = undefined;

    // ── session / scaling ─────────────────────────────────────────────
    this.lastDayStamp = undefined;
    this.symScale = 1.0;

    // ── morning frame (MH/ML) ─────────────────────────────────────────
    this.MH = undefined; this.ML = undefined;
    this.frameReady = false; this.mhFired = false; this.mlFired = false;

    // ── trend hysteresis ───────────────────────────────────────────────
    this.trendState = 'SIDEWAYS';
    this.trendConfirmed = false;
    this.structHigh = undefined;
    this.structLow = undefined;

    // ── pivots — rolling anchors ───────────────────────────────────────
    this.lastPH = undefined; this.lastPHBar = undefined;
    this.lastPL = undefined; this.lastPLBar = undefined;
    this.lastPLStrict = false; this.lastPHReach = false;
    this.lastPHTouch = undefined; this.lastPHTouchBar = undefined;
    this.lastPLBelow = undefined; this.lastPLBelowBar = undefined;

    // ── T5H state (double top / short) ─────────────────────────────────
    this.t5hStage = 0;
    this.t5hP1 = undefined; this.t5hP1Bar = undefined;
    this.t5hP2Hi = undefined; this.t5hP2Lo = undefined; this.t5hP2Bar = undefined;
    this.t5hP3 = undefined; this.t5hP3Bar = undefined;
    this.t5hP4 = undefined; this.t5hP4Bar = undefined;
    this.t5hP5Low = undefined; this.t5hP5LW = undefined; this.t5hP5Bar = undefined;
    this.t5hP6 = undefined; this.t5hP6Bar = undefined; // UI-only: point-6 confirm price/bar
    this.t5hPend = 0;
    this.t5hSeedBar = undefined;
    this.t5hCaut = false; this.t5hCautLow = undefined;
    this.t5h3nc = false; this.t5h3ncLow = undefined;
    this.t5h6nc = false; this.t5h6ncClose = undefined; this.t5h6ncHigh = undefined; this.t5h6ncBody = undefined;
    this.t5hApexHi = undefined; this.t5hApexBar = undefined; this.t5hApexPoke = false;
    this.t5h4Sent = false;

    // ── T5L state (double bottom / long) ───────────────────────────────
    this.t5lStage = 0;
    this.t5lP1 = undefined; this.t5lP1Bar = undefined;
    this.t5lP2Lo = undefined; this.t5lP2Hi = undefined; this.t5lP2Bar = undefined;
    this.t5lP3 = undefined; this.t5lP3Bar = undefined;
    this.t5lP4 = undefined; this.t5lP4Bar = undefined;
    this.t5lP5High = undefined; this.t5lP5UW = undefined; this.t5lP5Bar = undefined;
    this.t5lP6 = undefined; this.t5lP6Bar = undefined; // UI-only: point-6 confirm price/bar
    this.t5lPend = 0;
    this.t5lCaut = false; this.t5lCautHigh = undefined;
    this.t5l3nc = false; this.t5l3ncHigh = undefined;
    this.t5l6nc = false; this.t5l6ncClose = undefined; this.t5l6ncLow = undefined; this.t5l6ncBody = undefined;
    this.t5lApexLo = undefined; this.t5lApexBar = undefined; this.t5lApexPoke = false;
    this.t5l4Sent = false;
    this.t5lRoomOK = true; this.t5lRoomVal = undefined;

    // ── cross-machine hand-off seeds (Sr. 66/93) ───────────────────────
    this.seedT5L1 = undefined; this.seedT5L1Bar = undefined;
    this.seedT5H1 = undefined; this.seedT5H1Bar = undefined;
  }

  // ── day-boundary helper ────────────────────────────────────────────
  _dayKey(timeMs) {
    return new Intl.DateTimeFormat('en-CA', { timeZone: this.timezone, year: 'numeric', month: '2-digit', day: '2-digit' })
      .format(new Date(timeMs));
  }

  /**
   * Process one CLOSED candle. Returns { events, state }.
   * events: [{ tag, actionable, side, provisional, price, note }]
   */
  addBar(candle) {
    const { time, open, high, low, close } = candle;
    const isGreen = close > open;
    const bodyTop = Math.max(open, close);
    const bodyBot = Math.min(open, close);
    const UW = high - bodyTop;
    const LW = bodyBot - low;

    this.O.push(open); this.H.push(high); this.L.push(low); this.C.push(close);
    this.isGreenS.push(isGreen); this.bodyTopS.push(bodyTop); this.bodyBotS.push(bodyBot);
    this.timeS.push(time);
    this.barIndex++;

    // ── the 9EMA band ────────────────────────────────────────────────
    const alpha = 2 / (9 + 1);
    const bandHigh = na(this._emaHighPrev) ? high : alpha * high + (1 - alpha) * this._emaHighPrev;
    const bandLow = na(this._emaLowPrev) ? low : alpha * low + (1 - alpha) * this._emaLowPrev;
    this._emaHighPrev = bandHigh; this._emaLowPrev = bandLow;
    this.bandHighS.push(bandHigh); this.bandLowS.push(bandLow);

    // Resolves an absolute bar index to the real candle time it happened
    // on (via timeS). Falls back to the current bar's time if the index
    // is missing/out of range, so a bad bar reference degrades to the old
    // (still-correct-most-of-the-time) behaviour instead of throwing/NaN.
    const barTime = (bar) => {
      const t = this.timeS.at(bar);
      return na(t) ? time : t;
    };

    const events = [];
    const emit = (tag, side, opts = {}) => {
      events.push({
        tag, side, actionable: ACTIONABLE_TAGS.has(tag),
        provisional: opts.provisional ?? false,
        price: opts.price ?? undefined,
        note: opts.note ?? '',
        // Every point/flip must be traceable to the exact candle Pine drew
        // it on — never a derived/approximate timestamp, never scan time.
        // Pivot-based points (P1/P2/P3/P5 — see barTime callers below) only
        // become *known* 1-2 bars after they happened, so those calls pass
        // an explicit `opts.time` (the real point bar); everything else
        // (P4 triggers, flips, confirms, NC/CAUT/done/expired) is evaluated
        // directly on the current bar with no lag, so it keeps the ambient
        // `time` via this default.
        time: opts.time ?? time,
        barIndex: this.barIndex,
      });
    };

    // ── session / day ────────────────────────────────────────────────
    const dayStamp = this._dayKey(time);
    const newDay = na(this.lastDayStamp) || dayStamp !== this.lastDayStamp;
    this.lastDayStamp = dayStamp;

    if (newDay && this.autoScale) this.symScale = Math.max(close / 24000.0, 0.000001);
    const bandNear = this.bandNearIn * this.symScale;
    const roomToP3 = this.t5RoomToP3In * this.symScale;

    // ── MH / ML — morning frame ──────────────────────────────────────
    if (newDay) {
      this.MH = high; this.ML = low;
      this.frameReady = false; this.mhFired = false; this.mlFired = false;
      // the frame is set AND ready on the confirm of the day's first bar,
      // since we only ever process closed candles here (barstate.isconfirmed)
      this.frameReady = true;
    }
    const mhBroken = this.frameReady && !na(this.MH) && high > this.MH && !this.mhFired;
    const mlBroken = this.frameReady && !na(this.ML) && low < this.ML && !this.mlFired;
    if (mhBroken) this.mhFired = true;
    if (mlBroken) this.mlFired = true;
    if (mhBroken || mlBroken) emit('MH / ML broken', null, { note: 'Morning frame crossed — observation only.' });

    // ── trend — baseline hysteresis + manual override ───────────────
    if (close > bandHigh && this.trendState !== 'UP') {
      this.trendState = 'UP'; this.trendConfirmed = false; this.structHigh = high;
    } else if (close < bandLow && this.trendState !== 'DOWN') {
      this.trendState = 'DOWN'; this.trendConfirmed = false; this.structLow = low;
    }
    if (this.trendState === 'UP') {
      if (!this.trendConfirmed && isGreen && close > nz(this.structHigh, close)) this.trendConfirmed = true;
      this.structHigh = Math.max(nz(this.structHigh, high), high);
    } else if (this.trendState === 'DOWN') {
      if (!this.trendConfirmed && !isGreen && close < nz(this.structLow, close)) this.trendConfirmed = true;
      this.structLow = Math.min(nz(this.structLow, low), low);
    }
    const effTrend = this.trendMode === 'Auto' ? this.trendState
      : this.trendMode === 'Force UP' ? 'UP'
        : this.trendMode === 'Force DOWN' ? 'DOWN' : 'SIDEWAYS';
    const effConf = this.trendMode === 'Auto' ? this.trendConfirmed : true;
    const huntT5H = effTrend === 'UP' && effConf;
    const huntT5L = effTrend === 'DOWN' && effConf;
    const sidewaysNow = effTrend === 'SIDEWAYS';

    // ── pivots — 2-candle road + rolling retro anchors ───────────────
    const ph = pivotHigh(this.H, 2, 2);
    const pl = pivotLow(this.L, 2, 2);
    if (!na(ph)) {
      this.lastPH = ph; this.lastPHBar = this.barIndex - 2;
      this.lastPHReach = this.H.get(2) >= this.bandHighS.get(2);
    }
    if (!na(pl)) {
      this.lastPL = pl; this.lastPLBar = this.barIndex - 2;
      this.lastPLStrict = pl < this.bandLowS.get(2);
    }
    if (!na(ph) && this.H.get(2) >= this.bandHighS.get(2)) {
      this.lastPHTouch = ph; this.lastPHTouchBar = this.barIndex - 2;
    }
    if (!na(pl) && pl < this.bandLowS.get(2)) {
      this.lastPLBelow = pl; this.lastPLBelowBar = this.barIndex - 2;
    }

    // fast path (Sr. 70): opposite-colour rejection of the poke candle's close
    const fastHiNow = this.C.get(1) > this.O.get(1) && !isGreen && close < this.C.get(1);
    const fastHiPx = Math.max(high, nz(this.H.get(1), high));
    const fastLoNow = this.C.get(1) < this.O.get(1) && isGreen && close > this.C.get(1);
    const fastLoPx = Math.min(low, nz(this.L.get(1), low));

    // ══════════════════════════════════════════════════════════════
    //  T5H — the double top
    // ══════════════════════════════════════════════════════════════
    let t5hArmedNow = false, t5hRean = false, t5hGate2Now = false;
    let t5hP3Now = false, t5hP3ReanNow = false, t5h3ncNow = false, t5hCautNow = false;
    let t5hC3Flip = false, t5h5ncNow = false;
    let t5h4Fire = false, t5hP5Now = false, t5hS5Fire = false;
    let t5h6ncNow = false, t5h6ConfNow = false, t5h6ncFailNow = false;
    let t5hLFlip = false, t5hLFlipName = '', t5hS2Flip = false, t5hExpNow = false;
    let t5hRef = undefined;

    const t5hCeil = (!na(this.t5hP2Hi) && !na(this.t5hP1))
      ? this.t5hP2Hi + this.t5FlipFib * (this.t5hP2Hi - this.t5hP1) : undefined;
    const f_lastLowH = () => (!na(this.t5hP5Low) ? this.t5hP5Low : this.t5hP3);

    {
      // Sr. 113 — OVERNIGHT CARRY: no more session reset. Armed structures
      // survive the session boundary; flips/gates test from the first
      // candles of the new day. (Only MH/ML and symScale still reset daily
      // — see the block above.)

      if (this.t5hStage === 1 && (sidewaysNow || huntT5L)) this.t5hStage = 0;

      // point 1 candidate — strict pivot low below the band
      const strictNew = !na(pl) && pl < this.bandLowS.get(2);
      if (huntT5H && this.t5lStage === 0 && this.t5hStage === 0 && strictNew) {
        this.t5hStage = 1; this.t5hP1 = pl; this.t5hP1Bar = this.barIndex - 2;
      } else if (this.t5hStage === 1 && strictNew && pl < this.t5hP1) {
        this.t5hP1 = pl; this.t5hP1Bar = this.barIndex - 2;
      }
      // hand-off seed (Sr. 105/108 — must sit strictly below the band at its own bar)
      // Sr. 121 — ONE-STRUCTURE LAW: a seed arms only when T5L is idle too.
      if (this.t5hStage === 0 && this.t5lStage === 0 && !na(this.seedT5H1) && huntT5H) {
        const bandLowAtSeed = this.bandLowS.at(this.seedT5H1Bar);
        // Sr. 118 — a seed must be NEWER than the currently retained origin.
        if (this.seedT5H1 < bandLowAtSeed && (na(this.lastPLBelowBar) || this.seedT5H1Bar > this.lastPLBelowBar)) {
          this.t5hStage = 1; this.t5hP1 = this.seedT5H1; this.t5hP1Bar = this.seedT5H1Bar;
          this.t5hSeedBar = this.seedT5H1Bar;
          this.lastPLBelow = this.seedT5H1; this.lastPLBelowBar = this.seedT5H1Bar; // Sr. 116 — refresh only when the seed WINS
        } else if (!na(this.lastPLBelow)) {
          // Sr. 112 — a failing seed falls back to the RETAINED origin instead of dropping silently.
          this.t5hStage = 1; this.t5hP1 = this.lastPLBelow; this.t5hP1Bar = this.lastPLBelowBar;
          this.t5hSeedBar = this.lastPLBelowBar;
        }
        this.seedT5H1 = undefined; // consumed either way
      }

      // point 2 — pivot high at/above band bottom; arms (Sr. 71 fast path)
      const p2hFast = fastHiNow && high >= bandLow;
      const p2hSlow = !na(ph) && ph >= this.bandLowS.get(2);
      const p2hPx = p2hFast ? fastHiPx : ph;
      const p2hBar = p2hFast ? (high >= nz(this.H.get(1), -Infinity) ? this.barIndex : this.barIndex - 1) : this.barIndex - 2;
      const p2hCand = p2hFast || p2hSlow;
      // Sr. 117 — same-bar arbitration: does a VALID dip candidate exist
      // whose candle PRECEDES this bar's peak candidate?
      const hDipCand = this.t5hStage === 2 && ((fastLoNow && fastLoPx < this.t5hP2Hi && fastLoPx < bandHigh) ||
        (!na(pl) && pl < this.t5hP2Hi && pl < this.bandHighS.get(2)));
      const hDipBar = fastLoNow ? (low <= nz(this.L.get(1), Infinity) ? this.barIndex : this.barIndex - 1) : this.barIndex - 2;
      const hDipFirst = hDipCand && hDipBar >= this.t5hP2Bar + 2 && hDipBar < p2hBar;
      // Sr. 112 — the RETAINED ORIGIN serves the point-2-first road: the
      // last below-band pivot low, however far back (the real wave anchor).
      if (this.t5hStage === 0 && p2hCand && huntT5H && this.t5lStage === 0 &&
        !na(this.lastPLBelow) && this.lastPLBelow < p2hPx && this.lastPLBelowBar < p2hBar) {
        this.t5hStage = 1; this.t5hP1 = this.lastPLBelow; this.t5hP1Bar = this.lastPLBelowBar;
      }
      if (this.t5hStage === 1 && p2hCand && this.t5hP1 < p2hPx && this.t5hP1Bar < p2hBar - 1) {
        this.t5hStage = 2;
        this.t5hP2Hi = p2hPx;
        this.t5hP2Lo = p2hFast ? Math.max(this.bodyTopS.get(1), bodyTop) : Math.max(this.O.get(2), this.C.get(2));
        this.t5hP2Bar = p2hBar;
        this.t5hP3 = undefined; this.t5hP4 = undefined; this.t5hP5Low = undefined; this.t5hP5Bar = undefined;
        this.t5h3nc = false; this.t5hCaut = false; this.t5h6nc = false; this.t5h4Sent = false;
        this.t5hPend = 0; t5hArmedNow = true;
        // stage-2 ratchet (Sr. 64) — UNLESS the dip came first (Sr. 117):
        // then point 3 takes this bar and the peak faces the Sr. 114 ceiling.
      } else if (this.t5hStage === 2 && p2hCand && p2hPx > this.t5hP2Hi && this.t5hP1 < p2hPx && !hDipFirst) {
        this.t5hP2Hi = p2hPx;
        this.t5hP2Lo = p2hFast ? Math.max(this.bodyTopS.get(1), bodyTop) : Math.max(this.O.get(2), this.C.get(2));
        this.t5hP2Bar = p2hBar; t5hArmedNow = true; t5hRean = true;
      }

      // T5H3NC (Sr. 82)
      if (this.t5hStage === 2 && !this.t5h3nc && !this.t5hCaut && !isGreen && close < bandLow) {
        this.t5h3nc = true; this.t5h3ncLow = low; t5h3ncNow = true;
      }
      if (this.t5hStage === 2 && this.t5h3nc && !this.t5hCaut && !isGreen && close < this.t5h3ncLow) {
        this.t5hCaut = true; this.t5hCautLow = low; this.t5hCautHigh = high; t5hCautNow = true; // Sr. 124 — the caution BOX
      }

      // point 3 — pivot low < p2.high AND < bandHigh
      const p3Fast = fastLoNow && fastLoPx < this.t5hP2Hi && fastLoPx < bandHigh;
      const p3Slow = !na(pl) && pl < this.t5hP2Hi && pl < this.bandHighS.get(2);
      const p3Px = p3Fast ? fastLoPx : pl;
      const p3Bar = p3Fast ? (low <= nz(this.L.get(1), Infinity) ? this.barIndex : this.barIndex - 1) : this.barIndex - 2;
      if (this.t5hStage === 2 && (p3Fast || p3Slow) && p3Bar >= this.t5hP2Bar + 2) {
        this.t5hStage = 3; this.t5hP3 = p3Px; this.t5hP3Bar = p3Bar;
        this.t5hApexHi = high; this.t5hApexBar = this.barIndex; this.t5hApexPoke = high >= bandHigh - bandNear;
        this.t5h3nc = false; this.t5hCaut = false; t5hP3Now = true;
      }
      if (this.t5hStage === 3 && (p3Fast || p3Slow) && p3Px < this.t5hP3 && p3Px > this.t5hP1) {
        this.t5hP3 = p3Px; this.t5hP3Bar = p3Bar; t5hP3Now = true; t5hP3ReanNow = true;
      }

      // Sr. 114/122 — the point-4 window: CEILING = band + one UW above
      // T5H2; NEAR wall = T5H2 body minus one band-width (Sr. 122). Also
      // gates the break-adoption path below, computed here (inline, same
      // as Pine) since it's needed before the caution check.
      const t5hP4Cap = this.t5hP2Hi + (this.t5hP2Hi - this.t5hP2Lo);
      const t5hP4Near = this.t5hP2Lo - (this.t5hP2Hi - this.t5hP2Lo);

      // caution at stage 3 (Sr. 62/73), break-adoption gated by Sr. 122's near wall
      if (this.t5hStage === 3 && !this.t5hCaut && !isGreen && close < this.t5hP3 && close < bandLow) {
        if (this.t5hApexPoke && close < open && this.t5hApexHi >= t5hP4Near) {
          this.t5hP4 = this.t5hApexHi; this.t5hP4Bar = this.t5hApexBar;
          t5h4Fire = true; this.t5h4Sent = true; this.t5hStage = 5; this.t5hPend = 0;
        } else {
          this.t5hCaut = true; this.t5hCautLow = low; this.t5hCautHigh = high; t5hCautNow = true; // Sr. 124 — the caution BOX
        }
      }
      // Sr. 111 — PRICE IS THE LAW: caution never clears on a bounce, only
      // point 4 lifts it. Sr. 124 — the caution BOX resolves by CLOSES,
      // two-sided. Close BELOW the box -> S T5H3 FLIP (same-side disarm):
      if ((this.t5hStage === 2 || this.t5hStage === 3) && this.t5hCaut && !t5hCautNow && close < this.t5hCautLow) {
        t5hC3Flip = true;
        this.seedT5L1 = !na(this.lastPH) ? this.lastPH : this.t5hP2Hi;
        this.seedT5L1Bar = !na(this.lastPHBar) ? this.lastPHBar : this.t5hP2Bar;
        this.t5hStage = 0; this.t5hCaut = false; this.t5h3nc = false;
      }
      // Close ABOVE the box -> L T5H3 FLIP (opposite-side disarm — reuses
      // the existing trap-flip mechanism, Sr. 124):
      if ((this.t5hStage === 2 || this.t5hStage === 3) && this.t5hCaut && !t5hCautNow && close > this.t5hCautHigh) {
        t5hLFlip = true; t5hLFlipName = 'L T5H3 FLIP';
        this.seedT5H1 = f_lastLowH();
        this.seedT5H1Bar = (this.t5hStage === 3 && !na(this.t5hP3Bar)) ? this.t5hP3Bar : this.barIndex;
        this.t5hStage = 0; this.t5hCaut = false; this.t5h3nc = false;
      }

      // apex tracking at stage 3
      if (this.t5hStage === 3 && high > nz(this.t5hApexHi, high - 1)) {
        this.t5hApexHi = high; this.t5hApexBar = this.barIndex; this.t5hApexPoke = high >= bandHigh - bandNear;
      }

      // Sr. 100/114 — point-4 CEILING: a pivot above T5H2's new cap trails T5H2 up
      if ((this.t5hStage === 3 || this.t5hStage === 4) && p2hCand && p2hPx > t5hP4Cap) {
        t5hGate2Now = true;
        const guOk = !na(this.lastPLBelow) && this.lastPLBelow < p2hPx;
        this.t5hP1 = guOk ? this.lastPLBelow : this.t5hP3;
        this.t5hP1Bar = guOk ? this.lastPLBelowBar : this.t5hP3Bar;
        this.t5hP2Hi = p2hPx;
        this.t5hP2Lo = p2hFast ? Math.max(this.bodyTopS.get(1), bodyTop) : Math.max(this.O.get(2), this.C.get(2));
        this.t5hP2Bar = p2hBar;
        this.t5hP3 = undefined; this.t5hP4 = undefined; this.t5hPend = 0;
        this.t5h3nc = false; this.t5hCaut = false; this.t5h6nc = false; this.t5h4Sent = false;
        this.t5hStage = 2; t5hArmedNow = true; t5hRean = true;
      }

      // point 4 — poke of the band top, above p3, within the Sr. 114/122 window
      const h1 = this.H.get(1), c1 = this.C.get(1), o1 = this.O.get(1), bh1 = this.bandHighS.get(1);
      const p4Fast = !na(c1) && c1 > o1 && h1 >= bh1 - bandNear && !isGreen && close < c1 && close < bandHigh &&
        Math.max(high, h1) <= t5hP4Cap;
      const p4Slow = !na(ph) && this.H.get(2) >= this.bandHighS.get(2) - bandNear && ph > this.t5hP3 && ph <= t5hP4Cap;
      // Sr. 126 — point 4 must sit >= 2 bars after point 3 (tightened from the v16.15 Sr.110 guard)
      if (this.t5hStage === 3 && p4Fast && Math.max(high, h1) > this.t5hP3 && Math.max(high, h1) >= t5hP4Near &&
        (high >= h1 ? this.barIndex : this.barIndex - 1) >= this.t5hP3Bar + 2) {
        this.t5hP4 = Math.max(high, h1);
        this.t5hP4Bar = high >= h1 ? this.barIndex : this.barIndex - 1;
        this.t5hCaut = false; // Sr. 111 — point 4 lifts the caution
        t5h4Fire = true; this.t5h4Sent = true; this.t5hStage = 5; this.t5hPend = 0;
      } else if (this.t5hStage === 3 && p4Slow && ph >= t5hP4Near && this.barIndex - 2 >= this.t5hP3Bar + 2) {
        this.t5hP4 = ph; this.t5hP4Bar = this.barIndex - 2;
        this.t5hCaut = false; // Sr. 111 — point 4 lifts the caution
        this.t5hStage = 4;
      }
      if (this.t5hStage === 4) {
        const red0 = !isGreen && close < bandHigh;
        const red1 = !na(c1) && !this.isGreenS.get(1) && c1 < bh1 && this.barIndex - 1 > this.t5hP4Bar;
        if (red0 || red1) { t5h4Fire = true; this.t5h4Sent = true; this.t5hStage = 5; this.t5hPend = 0; }
      }

      // point 5 — single-candle poke of the far edge
      if (this.t5hStage === 5) {
        if (!isGreen && low <= bandLow + bandNear && low < this.t5hP3) {
          this.t5hStage = 6; this.t5hP5Low = low; this.t5hP5LW = LW; this.t5hP5Bar = this.barIndex; this.t5hPend = 0; t5hP5Now = true;
        } else if ((fastLoNow && Math.abs(fastLoPx - this.t5hP3) <= bandNear) || (!na(pl) && Math.abs(pl - this.t5hP3) <= bandNear)) {
          // Sr. 119 — DUMMY point-5 NC: pivot near p3, band poke missed.
          // Nothing fires; the cycle moves on to hunt point 6.
          this.t5hStage = 6;
          this.t5hP5Low = fastLoNow ? fastLoPx : pl;
          this.t5hP5LW = fastLoNow ? (low <= nz(this.L.get(1), low) ? LW : this.bodyBotS.get(1) - this.L.get(1)) : this.bodyBotS.get(2) - this.L.get(2);
          this.t5hP5Bar = this.barIndex; this.t5hPend = 0; t5h5ncNow = true;
        } else {
          this.t5hPend += 1;
          if (this.t5hPend > this.t5PendingBars) { t5hExpNow = true; this.t5hStage = 0; }
        }
      }

      // stage 6 — point-6 NC road + S continuation
      if (this.t5hStage === 6) {
        if (low < bandLow && low < this.t5hP3 && low < this.t5hP5Low - this.t5hP5LW) {
          t5hS5Fire = true; this.t5hStage = 0;
        } else {
          if (!this.t5h6nc && isGreen && close > bandHigh && high < this.t5hP4) {
            this.t5h6nc = true; this.t5h6ncClose = close; this.t5h6ncHigh = high; this.t5h6ncBody = bodyTop; t5h6ncNow = true;
          } else if (this.t5h6nc && !t5h6ncNow) {
            if (low < this.t5h6ncClose) { t5h6ConfNow = true; t5hRef = this.t5h6ncBody; this.t5hP6 = this.t5h6ncBody; this.t5hP6Bar = this.barIndex; this.t5hStage = 0; }
            else if (high > this.t5h6ncHigh) { t5h6ncFailNow = true; this.t5h6nc = false; }
          }
          if (this.t5hStage === 6) {
            this.t5hPend += 1;
            if (this.t5hPend > this.t5PendingBars) { t5hExpNow = true; this.t5hStage = 0; }
          }
        }
      }

      // the ONE trap flip (Sr. 92/96). Sr. 124b — a CLOSE above the
      // point-2 band top is a DEFINITE flip even without touching the
      // fib-buffered ceiling (widened OR condition, same relative order —
      // still runs after point 4/5/6, per the Pine source's own flagged
      // gate-2-ordering caveat).
      if (this.t5hStage >= 3 && this.t5hStage <= 6 &&
        ((!na(t5hCeil) && high > t5hCeil) || (!na(this.t5hP2Hi) && close > this.t5hP2Hi))) {
        t5hLFlip = true;
        t5hLFlipName = (this.t5h6nc || t5h6ConfNow) ? 'L T5H6 FLIP'
          : this.t5hStage === 6 ? 'L T5H5 FLIP'
            : !na(this.t5hP4) ? 'L T5H4 FLIP' : 'L T5H3 FLIP';
        if (this.t5h6nc) { t5h6ncFailNow = true; this.t5h6nc = false; }
        this.seedT5H1 = f_lastLowH();
        this.seedT5H1Bar = this.t5hStage === 6 ? this.barIndex : this.t5hP3Bar;
        this.t5hStage = 0;
      }

      // S T5H2 FLIP (Sr. 60/65/66)
      if (this.t5hStage === 2 && low < this.t5hP1) {
        t5hS2Flip = true;
        this.seedT5L1 = this.t5hP2Hi; this.seedT5L1Bar = this.t5hP2Bar;
        this.t5hStage = 0; this.t5h3nc = false; this.t5hCaut = false;
      }
    }

    // cancel: a trap flip retracting an already-fired T5H4 trigger (R33·20/23)
    if (t5hLFlip && this.t5h4Sent) {
      emit('✕ S T5H4 CANCELLED', 'short', { note: 'Trap ceiling flip retracted the short (R33·20/23).' });
    }

    // ── emit T5H events, in cheat-sheet order ─────────────────────────
    // Point-formation INFO marks — no alertcondition in Pine (these are
    // just drawn labels), but the cheat-sheet lists them as their own INFO
    // row ("T5H1…T5H6 — drawn as they form") and the UI timeline needs a
    // real candle time per point, so we surface them here as non-actionable
    // events (not in ACTIONABLE_TAGS — pure context, same as NC/CAUT/done).
    // T5H1 re-emits on first arming AND on a gate-2 hand-off (t5hGate2Now),
    // since a gate-2 re-arm can move the real origin bar backward in time
    // (this.t5hP1/t5hP1Bar re-assigned around the "Sr. 100" trail-up block).
    // A plain point-2 ratchet (t5hRean true, t5hGate2Now false) does NOT
    // move P1, so it must NOT re-emit — mirrors Pine's redraw guard, which
    // only redraws T5H1 when t5hP1Bar actually changes (v16.01 changelog:
    // "origin no longer redrawn on point-2 re-anchors when point 1 did not
    // move").
    if ((t5hArmedNow && !t5hRean) || t5hGate2Now) emit('T5H1', 'short', { price: this.t5hP1, note: 'Point 1 anchor (Sr. 112).', time: barTime(this.t5hP1Bar) });
    if (t5hArmedNow) emit('T5H2', 'short', { price: this.t5hP2Hi, note: 'Point 2 armed (Sr. 99).', time: barTime(this.t5hP2Bar) });
    if (t5hP3Now) emit('T5H3', 'short', { price: this.t5hP3, note: 'Point 3 formed.', time: barTime(this.t5hP3Bar) });
    if (t5hP5Now) emit('T5H5', 'short', { price: this.t5hP5Low, note: 'Point 5 poke of the far edge.', time: barTime(this.t5hP5Bar) });
    if (t5h4Fire) emit('S T5H4', 'short', { provisional: true, price: this.t5hP4, note: 'First red close below 9EMA High (R33·12). Provisional until point 5.' });
    if (t5h6ConfNow) emit('S T5H6', 'short', { price: t5hRef, note: 'Point 6 confirmed by the poke (Sr. 95/97).' });
    if (t5hS5Fire) emit('S T5H5 FLIP', 'short', { note: 'Point-5 break continuation (Sr. 59). Disarmed; manual below.' });
    if (t5hS2Flip) emit('S T5H2 FLIP', 'short', { note: 'Point-1 break — trend reverse (Sr. 60/65/66). Hands off to T5L1.' });
    if (t5hLFlip) emit('L T5H FLIP (trap)', 'long', { note: `${t5hLFlipName} — trap ceiling, intrabar-committed (Sr. 92/96).` });
    if (t5hCautNow) emit('S/L CAUT T5H3 FLIP', null, { note: 'Checkpoint — structure alive, PERSISTS until point 4 (Sr. 73/111/124).' });
    if (t5h3ncNow) emit('T5H3NC', null, { note: 'Provisional (Sr. 82) — not a signal.' });
    if (t5h6ncNow) emit('T5H6NC', null, { note: 'Provisional (Sr. 95) — not a signal.' });
    if (t5h5ncNow) emit('T5H5NC', null, { note: 'Sr. 119 — DUMMY: pivot near point 3, band poke missed. No action; cycle advances to hunt point 6.' });
    if (t5hC3Flip) emit('S T5H3 FLIP', 'short', { note: 'Sr. 111/124 — caution box low breached on close. DISARM; hand-off to T5L1.' });
    if (t5hGate2Now) emit('T5H gate 2 → re-armed', null, { note: 'Sr. 100/108/114 — pivot beyond the point-4 cap re-anchored the structure.', time: barTime(this.t5hP2Bar) });
    if (t5hExpNow) emit('T5H ✕ expired', null, { note: 'Point 5/6 unresolved within the pending window (R33·14).' });
    if (t5hS2Flip || t5hLFlip || t5hS5Fire || t5h6ConfNow || t5hC3Flip) emit('T5H ✓ done', null, { note: 'Structure resolved and disarmed (Sr. 67).' });

    // ══════════════════════════════════════════════════════════════
    //  T5L — the mirror (double bottom / long), with gates 2/3
    // ══════════════════════════════════════════════════════════════
    let t5lArmedNow = false, t5lRean = false, t5lP3Now = false, t5lP3ReanNow = false;
    let t5l3ncNow = false, t5lCautNow = false, t5l4Fire = false, t5l4Supp = false;
    let t5lC3Flip = false, t5l5ncNow = false;
    let t5lGate2Now = false, t5lP5Now = false, t5lL5Fire = false;
    let t5l6ncNow = false, t5l6ConfNow = false, t5l6ncFailNow = false;
    let t5lSFlip = false, t5lSFlipName = '', t5lL2Flip = false, t5lExpNow = false;
    let t5lRef = undefined;

    const t5lFloor = (!na(this.t5lP2Lo) && !na(this.t5lP1))
      ? this.t5lP2Lo - this.t5FlipFib * (this.t5lP1 - this.t5lP2Lo) : undefined;
    const f_lastHighL = () => (!na(this.t5lP5High) ? this.t5lP5High : this.t5lP3);

    {
      // Sr. 113 — overnight carry (mirror): no session reset.

      if (this.t5lStage === 1 && (sidewaysNow || huntT5H)) this.t5lStage = 0;

      // point 1 — relaxed: pivot high reaching the band
      const reachNew = !na(ph) && this.H.get(2) >= this.bandHighS.get(2);
      if (huntT5L && this.t5hStage === 0 && this.t5lStage === 0 && reachNew) {
        this.t5lStage = 1; this.t5lP1 = ph; this.t5lP1Bar = this.barIndex - 2;
      } else if (this.t5lStage === 1 && reachNew && ph > this.t5lP1) {
        this.t5lP1 = ph; this.t5lP1Bar = this.barIndex - 2;
      }
      // hand-off seeds. Sr. 121 — ONE-STRUCTURE LAW: a seed arms only when T5H is idle too.
      if (this.t5lStage === 0 && this.t5hStage === 0 && !na(this.seedT5L1) && huntT5L) {
        const bandHighAtSeed = this.bandHighS.at(this.seedT5L1Bar);
        // Sr. 118 mirror — seed recency
        if (this.seedT5L1 >= bandHighAtSeed && (na(this.lastPHTouchBar) || this.seedT5L1Bar > this.lastPHTouchBar)) {
          this.t5lStage = 1; this.t5lP1 = this.seedT5L1; this.t5lP1Bar = this.seedT5L1Bar;
          this.lastPHTouch = this.seedT5L1; this.lastPHTouchBar = this.seedT5L1Bar; // refresh only when the seed WINS
        } else if (!na(this.lastPHTouch)) {
          // Sr. 112 mirror — failing seed -> retained origin
          this.t5lStage = 1; this.t5lP1 = this.lastPHTouch; this.t5lP1Bar = this.lastPHTouchBar;
        }
        this.seedT5L1 = undefined;
      }

      // point 2 — pivot low at/below band top; arms
      const p2lFast = fastLoNow && low <= bandHigh;
      const p2lSlow = !na(pl) && pl <= this.bandHighS.get(2);
      const p2lPx = p2lFast ? fastLoPx : pl;
      const p2lBar = p2lFast ? (low <= nz(this.L.get(1), Infinity) ? this.barIndex : this.barIndex - 1) : this.barIndex - 2;
      const p2lCand = p2lFast || p2lSlow;
      // Sr. 117 mirror — same-bar arbitration
      const lDipCand = this.t5lStage === 2 && ((fastHiNow && fastHiPx > this.t5lP2Lo && fastHiPx > bandLow) ||
        (!na(ph) && ph > this.t5lP2Lo && ph > this.bandLowS.get(2)));
      const lDipBar = fastHiNow ? (high >= nz(this.H.get(1), -Infinity) ? this.barIndex : this.barIndex - 1) : this.barIndex - 2;
      const lDipFirst = lDipCand && lDipBar >= this.t5lP2Bar + 2 && lDipBar < p2lBar;
      // Sr. 112 mirror — retained origin: the last 9EMA-High-touching pivot
      if (this.t5lStage === 0 && p2lCand && huntT5L && this.t5hStage === 0 &&
        !na(this.lastPHTouch) && this.lastPHTouch > p2lPx && this.lastPHTouchBar < p2lBar) {
        this.t5lStage = 1; this.t5lP1 = this.lastPHTouch; this.t5lP1Bar = this.lastPHTouchBar;
      }
      if (this.t5lStage === 1 && p2lCand && this.t5lP1 > p2lPx && this.t5lP1Bar < p2lBar - 1) {
        this.t5lStage = 2;
        this.t5lP2Lo = p2lPx;
        this.t5lP2Hi = p2lFast ? Math.min(this.bodyBotS.get(1), bodyBot) : Math.min(this.O.get(2), this.C.get(2));
        this.t5lP2Bar = p2lBar;
        this.t5lP3 = undefined; this.t5lP4 = undefined; this.t5lP5High = undefined; this.t5lP5Bar = undefined;
        this.t5l3nc = false; this.t5lCaut = false; this.t5l6nc = false; this.t5l4Sent = false;
        this.t5lRoomOK = true; this.t5lPend = 0; t5lArmedNow = true;
      } else if (this.t5lStage === 2 && p2lCand && p2lPx < this.t5lP2Lo && this.t5lP1 > p2lPx && !lDipFirst) {
        this.t5lP2Lo = p2lPx;
        this.t5lP2Hi = p2lFast ? Math.min(this.bodyBotS.get(1), bodyBot) : Math.min(this.O.get(2), this.C.get(2));
        this.t5lP2Bar = p2lBar; t5lArmedNow = true; t5lRean = true;
      }

      // T5L3NC (mirror)
      if (this.t5lStage === 2 && !this.t5l3nc && !this.t5lCaut && isGreen && close > bandHigh) {
        this.t5l3nc = true; this.t5l3ncHigh = high; t5l3ncNow = true;
      }
      if (this.t5lStage === 2 && this.t5l3nc && !this.t5lCaut && isGreen && close > this.t5l3ncHigh) {
        this.t5lCaut = true; this.t5lCautHigh = high; this.t5lCautLow = low; t5lCautNow = true; // Sr. 124 — the caution BOX
      }

      // point 3 — pivot high > p2.low AND > bandLow
      const q3Fast = fastHiNow && fastHiPx > this.t5lP2Lo && fastHiPx > bandLow;
      const q3Slow = !na(ph) && ph > this.t5lP2Lo && ph > this.bandLowS.get(2);
      const q3Px = q3Fast ? fastHiPx : ph;
      const q3Bar = q3Fast ? (high >= nz(this.H.get(1), -Infinity) ? this.barIndex : this.barIndex - 1) : this.barIndex - 2;
      if (this.t5lStage === 2 && (q3Fast || q3Slow) && q3Bar >= this.t5lP2Bar + 2) {
        this.t5lStage = 3; this.t5lP3 = q3Px; this.t5lP3Bar = q3Bar;
        this.t5lApexLo = low; this.t5lApexBar = this.barIndex; this.t5lApexPoke = low <= bandLow + bandNear;
        this.t5l3nc = false; this.t5lCaut = false; t5lP3Now = true;
      }
      if (this.t5lStage === 3 && (q3Fast || q3Slow) && q3Px > this.t5lP3 && q3Px < this.t5lP1) {
        this.t5lP3 = q3Px; this.t5lP3Bar = q3Bar; t5lP3Now = true; t5lP3ReanNow = true;
      }

      // Sr. 100/114 mirror — point-4 FLOOR = band + one LW below T5L2;
      // Sr. 122 mirror — NEAR wall. Computed here (inline, like the Pine
      // source) since it's needed before the caution check below.
      const t5lP4Cap = this.t5lP2Lo - (this.t5lP2Hi - this.t5lP2Lo);
      const t5lP4Near = this.t5lP2Hi + (this.t5lP2Hi - this.t5lP2Lo);

      // caution at stage 3 (mirror), break-adoption gated by Sr. 122's near wall
      if (this.t5lStage === 3 && !this.t5lCaut && isGreen && close > this.t5lP3 && close > bandHigh) {
        if (this.t5lApexPoke && close > open && this.t5lApexLo <= t5lP4Near) {
          this.t5lP4 = this.t5lApexLo; this.t5lP4Bar = this.t5lApexBar;
          this.t5lRoomVal = this.t5lP3 - this.t5lApexLo;
          this.t5lRoomOK = this.t5lRoomVal >= roomToP3;
          if (this.t5lRoomOK) { t5l4Fire = true; this.t5l4Sent = true; } else { t5l4Supp = true; }
          this.t5lStage = 5; this.t5lPend = 0;
        } else {
          this.t5lCaut = true; this.t5lCautHigh = high; this.t5lCautLow = low; t5lCautNow = true; // Sr. 124 — the caution BOX
        }
      }
      // Sr. 111 mirror — caution never clears on a pullback, only point 4
      // lifts it. Sr. 124 mirror — close ABOVE the box -> L T5L3 FLIP
      // (same-side disarm, since T5L is the long/up structure):
      if ((this.t5lStage === 2 || this.t5lStage === 3) && this.t5lCaut && !t5lCautNow && close > this.t5lCautHigh) {
        t5lC3Flip = true;
        this.seedT5H1 = !na(this.lastPL) ? this.lastPL : this.t5lP2Lo;
        this.seedT5H1Bar = !na(this.lastPLBar) ? this.lastPLBar : this.t5lP2Bar;
        this.t5lStage = 0; this.t5lCaut = false; this.t5l3nc = false;
      }
      // Close BELOW the box -> S T5L3 FLIP (opposite-side disarm — reuses
      // the existing trap-flip mechanism, Sr. 124 — the failure road):
      if ((this.t5lStage === 2 || this.t5lStage === 3) && this.t5lCaut && !t5lCautNow && close < this.t5lCautLow) {
        t5lSFlip = true; t5lSFlipName = 'S T5L3 FLIP';
        this.seedT5L1 = f_lastHighL();
        this.seedT5L1Bar = (this.t5lStage === 3 && !na(this.t5lP3Bar)) ? this.t5lP3Bar : this.barIndex;
        this.t5lStage = 0; this.t5lCaut = false; this.t5l3nc = false;
      }

      if (this.t5lStage === 3 && low < nz(this.t5lApexLo, low + 1)) {
        this.t5lApexLo = low; this.t5lApexBar = this.barIndex; this.t5lApexPoke = low <= bandLow + bandNear;
      }

      // Sr. 100/114 mirror — a pivot below T5L2's new floor trails T5L2 down
      if ((this.t5lStage === 3 || this.t5lStage === 4) && p2lCand && p2lPx < t5lP4Cap) {
        t5lGate2Now = true;
        const g2okA = !na(this.lastPHTouch) && this.lastPHTouch > p2lPx;
        this.t5lP1 = g2okA ? this.lastPHTouch : this.t5lP3;
        this.t5lP1Bar = g2okA ? this.lastPHTouchBar : this.t5lP3Bar;
        this.t5lP2Lo = p2lPx;
        this.t5lP2Hi = p2lFast ? Math.min(this.bodyBotS.get(1), bodyBot) : Math.min(this.O.get(2), this.C.get(2));
        this.t5lP2Bar = p2lBar;
        this.t5lP3 = undefined; this.t5lP4 = undefined; this.t5lPend = 0;
        this.t5l3nc = false; this.t5lCaut = false; this.t5l6nc = false; this.t5l4Sent = false;
        this.t5lRoomOK = true; this.t5lStage = 2; t5lArmedNow = true; t5lRean = true;
      }

      // point 4 — poke of the band bottom, below p3, within the Sr. 114/122 window, gates 2/3
      const l1 = this.L.get(1), c1b = this.C.get(1), o1b = this.O.get(1), bl1 = this.bandLowS.get(1);
      const q4Fast = !na(c1b) && c1b < o1b && l1 <= bl1 + bandNear && isGreen && close > c1b && close > bandLow;
      const q4Slow = !na(pl) && this.L.get(2) <= this.bandLowS.get(2) + bandNear && pl < this.t5lP3;
      const q4Px = q4Fast ? Math.min(low, l1) : pl;
      const q4Bar = q4Fast ? (low <= l1 ? this.barIndex : this.barIndex - 1) : this.barIndex - 2;
      // Sr. 126 — point 4 must sit >= 2 bars after point 3
      if (this.t5lStage === 3 && (q4Fast || q4Slow) && q4Bar >= this.t5lP3Bar + 2 && q4Px <= t5lP4Near) {
        if (q4Px < t5lP4Cap) {
          // GATE 2 continuation — hand-off and re-arm (Sr. 53)
          t5lGate2Now = true;
          const g2okB = !na(this.lastPHTouch) && this.lastPHTouch > q4Px;
          this.t5lP1 = g2okB ? this.lastPHTouch : this.t5lP3;
          this.t5lP1Bar = g2okB ? this.lastPHTouchBar : this.t5lP3Bar;
          this.t5lP2Lo = q4Px;
          this.t5lP2Hi = q4Fast ? Math.min(this.bodyBotS.get(1), bodyBot) : Math.min(this.O.get(2), this.C.get(2));
          this.t5lP2Bar = q4Bar;
          this.t5lP3 = undefined; this.t5lP4 = undefined; this.t5lPend = 0;
          this.t5l3nc = false; this.t5lCaut = false; this.t5l6nc = false; this.t5l4Sent = false;
          this.t5lRoomOK = true; this.t5lStage = 2; t5lArmedNow = true; t5lRean = true;
        } else {
          this.t5lP4 = q4Px; this.t5lP4Bar = q4Bar;
          this.t5lCaut = false; // Sr. 111 — point 4 lifts the caution
          this.t5lRoomVal = this.t5lP3 - q4Px;
          this.t5lRoomOK = this.t5lRoomVal >= roomToP3;
          if (q4Fast) {
            if (this.t5lRoomOK) { t5l4Fire = true; this.t5l4Sent = true; } else { t5l4Supp = true; }
            this.t5lStage = 5; this.t5lPend = 0;
          } else {
            this.t5lStage = 4;
          }
        }
      }
      if (this.t5lStage === 4) {
        const grn0 = isGreen && close > bandLow;
        const grn1 = !na(c1b) && this.isGreenS.get(1) && c1b > bl1 && this.barIndex - 1 > this.t5lP4Bar;
        if (grn0 || grn1) {
          if (this.t5lRoomOK) { t5l4Fire = true; this.t5l4Sent = true; } else { t5l4Supp = true; }
          this.t5lStage = 5; this.t5lPend = 0;
        }
      }

      // point 5 — green high pokes the band top, above p3
      if (this.t5lStage === 5) {
        if (isGreen && high >= bandHigh - bandNear && high > this.t5lP3) {
          this.t5lStage = 6; this.t5lP5High = high; this.t5lP5UW = UW; this.t5lP5Bar = this.barIndex; this.t5lPend = 0; t5lP5Now = true;
        } else if ((fastHiNow && Math.abs(fastHiPx - this.t5lP3) <= bandNear) || (!na(ph) && Math.abs(ph - this.t5lP3) <= bandNear)) {
          // Sr. 119 mirror — dummy point-5 NC
          this.t5lStage = 6;
          this.t5lP5High = fastHiNow ? fastHiPx : ph;
          this.t5lP5UW = fastHiNow ? (high >= nz(this.H.get(1), -Infinity) ? UW : this.H.get(1) - this.bodyTopS.get(1)) : this.H.get(2) - this.bodyTopS.get(2);
          this.t5lP5Bar = this.barIndex; this.t5lPend = 0; t5l5ncNow = true;
        } else {
          this.t5lPend += 1;
          if (this.t5lPend > this.t5PendingBars) { t5lExpNow = true; this.t5lStage = 0; }
        }
      }

      // stage 6 — NC road + L continuation
      if (this.t5lStage === 6) {
        if (high > bandHigh && high > this.t5lP3 && high > this.t5lP5High + this.t5lP5UW) {
          t5lL5Fire = true; this.t5lStage = 0;
        } else {
          if (!this.t5l6nc && !isGreen && close < bandLow && low > this.t5lP4) {
            this.t5l6nc = true; this.t5l6ncClose = close; this.t5l6ncLow = low; this.t5l6ncBody = bodyBot; t5l6ncNow = true;
          } else if (this.t5l6nc && !t5l6ncNow) {
            if (high > this.t5l6ncClose) { t5l6ConfNow = true; t5lRef = this.t5l6ncBody; this.t5lP6 = this.t5l6ncBody; this.t5lP6Bar = this.barIndex; this.t5lStage = 0; }
            else if (low < this.t5l6ncLow) { t5l6ncFailNow = true; this.t5l6nc = false; }
          }
          if (this.t5lStage === 6) {
            this.t5lPend += 1;
            if (this.t5lPend > this.t5PendingBars) { t5lExpNow = true; this.t5lStage = 0; }
          }
        }
      }

      // the ONE trap flip (S side). Sr. 124b mirror — a CLOSE below the
      // point-2 band bottom is a DEFINITE flip (widened OR condition).
      if (this.t5lStage >= 3 && this.t5lStage <= 6 &&
        ((!na(t5lFloor) && low < t5lFloor) || (!na(this.t5lP2Lo) && close < this.t5lP2Lo))) {
        t5lSFlip = true;
        t5lSFlipName = (this.t5l6nc || t5l6ConfNow) ? 'S T5L6 FLIP'
          : this.t5lStage === 6 ? 'S T5L5 FLIP'
            : !na(this.t5lP4) ? 'S T5L4 FLIP' : 'S T5L3 FLIP';
        if (this.t5l6nc) { t5l6ncFailNow = true; this.t5l6nc = false; }
        this.seedT5L1 = f_lastHighL();
        this.seedT5L1Bar = this.t5lStage === 6 ? this.barIndex : this.t5lP3Bar;
        this.t5lStage = 0;
      }

      // L T5L2 FLIP (mirror)
      if (this.t5lStage === 2 && high > this.t5lP1) {
        t5lL2Flip = true;
        this.seedT5H1 = this.t5lP2Lo; this.seedT5H1Bar = this.t5lP2Bar;
        this.t5lStage = 0; this.t5l3nc = false; this.t5lCaut = false;
      }
    }

    // cancel: a trap flip retracting an already-fired T5L4 trigger
    if (t5lSFlip && this.t5l4Sent) {
      emit('✕ L T5L4 CANCELLED', 'long', { note: 'Trap floor flip retracted the long (R33·20/23).' });
    }

    // ── emit T5L events, in cheat-sheet order ─────────────────────────
    // T5L1 re-emits on first arming AND on a gate-2 hand-off (t5lGate2Now),
    // since a gate-2 re-arm can move the real origin bar backward in time
    // (this.t5lP1/t5lP1Bar re-assigned in either of the two "Sr. 100/53"
    // trail-down blocks above). A plain point-2 ratchet (t5lRean true,
    // t5lGate2Now false) does NOT move P1, so it must NOT re-emit — mirrors
    // Pine's redraw guard, which only redraws T5L1 when t5lP1Bar actually
    // changes (v16.01 changelog: "origin no longer redrawn on point-2
    // re-anchors when point 1 did not move").
    if ((t5lArmedNow && !t5lRean) || t5lGate2Now) emit('T5L1', 'long', { price: this.t5lP1, note: 'Point 1 anchor (Sr. 112).', time: barTime(this.t5lP1Bar) });
    if (t5lArmedNow) emit('T5L2', 'long', { price: this.t5lP2Lo, note: 'Point 2 armed (Sr. 99).', time: barTime(this.t5lP2Bar) });
    if (t5lP3Now) emit('T5L3', 'long', { price: this.t5lP3, note: 'Point 3 formed.', time: barTime(this.t5lP3Bar) });
    if (t5lP5Now) emit('T5L5', 'long', { price: this.t5lP5High, note: 'Point 5 poke of the far edge.', time: barTime(this.t5lP5Bar) });
    if (t5l4Fire) emit('L T5L4', 'long', { provisional: true, price: this.t5lP4, note: 'First green close above 9EMA Low. Provisional until point 5.' });
    if (t5l6ConfNow) emit('L T5L6', 'long', { price: t5lRef, note: 'Point 6 confirmed by the poke (Sr. 95/97).' });
    if (t5lL5Fire) emit('L T5L5 FLIP', 'long', { note: 'Point-5 break continuation (Sr. 59). Disarmed; manual above.' });
    if (t5lL2Flip) emit('L T5L2 FLIP', 'long', { note: 'Point-1 break — trend reverse (Sr. 60/65/66). Hands off to T5H1.' });
    if (t5lSFlip) emit('S T5L FLIP (trap)', 'short', { note: `${t5lSFlipName} — trap floor, intrabar-committed (Sr. 92/96).` });
    if (t5lCautNow) emit('S/L CAUT T5L3 FLIP', null, { note: 'Checkpoint — structure alive, PERSISTS until point 4 (Sr. 73/111/124 mirror).' });
    if (t5l3ncNow) emit('T5L3NC', null, { note: 'Provisional (Sr. 82) — not a signal.' });
    if (t5l6ncNow) emit('T5L6NC', null, { note: 'Provisional (Sr. 95) — not a signal.' });
    if (t5l5ncNow) emit('T5L5NC', null, { note: 'Sr. 119 — DUMMY: pivot near point 3, band poke missed. No action; cycle advances to hunt point 6.' });
    if (t5l4Supp) emit('L T5L4 ✕ gate 3', null, { note: `R33·26 — room ${this.t5lRoomVal?.toFixed(1)} below the scaled minimum (${roomToP3.toFixed(1)}); alert suppressed, structure continues.` });
    if (t5lC3Flip) emit('L T5L3 FLIP', 'long', { note: 'Sr. 111/124 — caution box high breached on close. DISARM; hand-off to T5H1.' });
    if (t5lGate2Now) emit('T5L gate 2 → re-armed', null, { note: 'Sr. 53/100/108/114 — pivot beyond the point-4 cap re-anchored the structure.', time: barTime(this.t5lP2Bar) });
    if (t5lExpNow) emit('T5L ✕ expired', null, { note: 'Point 5/6 unresolved within the pending window (R33·14).' });
    if (t5lL2Flip || t5lSFlip || t5lL5Fire || t5l6ConfNow || t5lC3Flip) emit('T5L ✓ done', null, { note: 'Structure resolved and disarmed (Sr. 67).' });

    return { events, state: this.getState() };
  }

  /**
   * Intrabar (still-forming candle) watchers — Sr. 54. These READ current
   * state but never mutate it; the committed signal only fires from
   * addBar() once the candle actually closes. Pass the live/streaming
   * candle currently in progress: { open, high, low, close }.
   */
  checkIntrabar(liveCandle) {
    const { high, low } = liveCandle;
    const out = [];
    const t5hCeil = (!na(this.t5hP2Hi) && !na(this.t5hP1))
      ? this.t5hP2Hi + this.t5FlipFib * (this.t5hP2Hi - this.t5hP1) : undefined;
    const t5lFloor = (!na(this.t5lP2Lo) && !na(this.t5lP1))
      ? this.t5lP2Lo - this.t5FlipFib * (this.t5lP1 - this.t5lP2Lo) : undefined;

    if (this.t5hStage >= 3 && this.t5hStage <= 6 && !na(t5hCeil) && high > t5hCeil) {
      out.push({ tag: 'L T5H FLIP (trap)', side: 'long', actionable: false, provisional: true, note: 'INTRABAR — trap ceiling traded (R33·54). Commits at close.' });
    }
    if (this.t5lStage >= 3 && this.t5lStage <= 6 && !na(t5lFloor) && low < t5lFloor) {
      out.push({ tag: 'S T5L FLIP (trap)', side: 'short', actionable: false, provisional: true, note: 'INTRABAR — trap floor traded (R33·54). Commits at close.' });
    }
    if (this.t5hStage === 2 && !na(this.t5hP1) && low < this.t5hP1) {
      out.push({ tag: 'S T5H2 FLIP', side: 'short', actionable: false, provisional: true, note: 'INTRABAR — T5H1 traded through (Sr. 60). Commits at close.' });
    }
    if (this.t5lStage === 2 && !na(this.t5lP1) && high > this.t5lP1) {
      out.push({ tag: 'L T5L2 FLIP', side: 'long', actionable: false, provisional: true, note: 'INTRABAR — T5L1 traded through (Sr. 60). Commits at close.' });
    }
    return out;
  }

  /** Panel-equivalent snapshot of current machine state. */
  getState() {
    return {
      t5h: {
        stage: this.t5hStage, caution: this.t5hCaut, nc3: this.t5h3nc, nc6: this.t5h6nc,
        pending: this.t5hPend, pendingLimit: this.t5PendingBars,
        p1: this.t5hP1, p1Bar: this.t5hP1Bar,
        p2Hi: this.t5hP2Hi, p2Lo: this.t5hP2Lo, p2Bar: this.t5hP2Bar,
        p3: this.t5hP3, p3Bar: this.t5hP3Bar,
        p4: this.t5hP4, p4Bar: this.t5hP4Bar,
        p5: this.t5hP5Low, p5Bar: this.t5hP5Bar,
        p6: this.t5hP6, p6Bar: this.t5hP6Bar,
      },
      t5l: {
        stage: this.t5lStage, caution: this.t5lCaut, nc3: this.t5l3nc, nc6: this.t5l6nc,
        pending: this.t5lPend, pendingLimit: this.t5PendingBars,
        p1: this.t5lP1, p1Bar: this.t5lP1Bar,
        p2Lo: this.t5lP2Lo, p2Hi: this.t5lP2Hi, p2Bar: this.t5lP2Bar,
        p3: this.t5lP3, p3Bar: this.t5lP3Bar,
        p4: this.t5lP4, p4Bar: this.t5lP4Bar,
        p5: this.t5lP5High, p5Bar: this.t5lP5Bar,
        p6: this.t5lP6, p6Bar: this.t5lP6Bar,
        roomOK: this.t5lRoomOK,
      },
      trend: { state: this.trendState, confirmed: this.trendConfirmed },
      scale: this.symScale,
      band: { high: this.bandHighS.get(0), low: this.bandLowS.get(0) },
    };
  }
}

// ── ES module exports (added for the frontend copy only — see header) ──
export { TgT5Engine, ACTIONABLE_TAGS, Series, pivotHigh, pivotLow };